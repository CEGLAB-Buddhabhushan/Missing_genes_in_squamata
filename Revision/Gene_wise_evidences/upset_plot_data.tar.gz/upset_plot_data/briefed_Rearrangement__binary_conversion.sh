#!/bin/bash

# Check if correct number of arguments provided
if [ $# -ne 2 ]; then
    echo "Usage: $0 <input_file.tsv> <output_file.tsv>"
    echo "Example: $0 binary_data.tsv briefed_segmental_binary.tsv"
fi

# Input and output files from command line arguments
input_file="$1"
output_file="$2"

# Check if input file exists
if [ ! -f "$input_file" ]; then
    echo "Error: Input file '$input_file' not found!"
fi

# Process the file
awk -F'\t' '
BEGIN {
    OFS="\t"
    # Print header for the new file
    print "Gene", "Synteny_Proof_Intrachromosomal", "Synteny_Proof_Interchromosomal", \
          "Intergenic_Distance_Evidence", "Phylogenetic_Signal", \
          "Genome_Blast_Coverage", "GC_Content_mean", "Sequence_Identity", \
          "Paralogs_status_Ensembl", "Closest_paralog_IQTREE"
}
NR > 1 {  # Skip header row
    # Extract columns
    gene = $1
    synteny_intra = $2
    synteny_inter = $3
    sig_pvals = $7
    ig10_pval = $8
    mple_pval = $9
    blast_coverage = $10
    gc_content = $11
    seq_identity = $13
    paralogs_status = $14
    closest_paralog = $15
    
    # Process Phylogenetic Signal: if either IG10_Pval or MPLE_Pval =1, then 1, else 0
    phylogenetic_signal = 0
    if (ig10_pval == 1  || mple_pval == 1) {
        phylogenetic_signal = 1
    }
    
    # Print the processed row
    print gene, synteny_intra, synteny_inter, sig_pvals, \
          phylogenetic_signal, blast_coverage, gc_content, seq_identity, \
          paralogs_status, closest_paralog
}' "$input_file" > "$output_file"

echo "Processing complete. Output saved to $output_file"
