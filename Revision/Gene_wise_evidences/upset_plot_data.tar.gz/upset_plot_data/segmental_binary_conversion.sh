#!/bin/bash
# Usage: ./binary_convert.sh input.tsv output.tsv
# Converts your table into binary format (0/1) according to rules.

input="$1"
output="$2"

awk -F'\t' -v OFS='\t' '
NR==1 {               # First row (header) → print as is
    print; next
}
{
    # Column 1: Gene name → keep unchanged
    # $1 = $1   (no modification needed)

    # -----------------------------
    # Column 2: Synteny Proof (Intrachromosomal Rearrangement)
    $2 = (tolower($2) ~ /^yes/) ? 1 : 0

    # Column 3: Synteny Proof (Interchromosomal Rearrangement)
    $3 = (tolower($3) ~ /^yes/) ? 1 : 0

    # Column 4: Status of Assembly Gaps (Crotalus_tigris PacBio)
    $4 = (tolower($4) ~ /^no/) ? 1 : 0

    # Column 5: Status of Assembly Gaps (Pogona_vitticeps_Nanopore)
    $5 = (tolower($5) ~ /^no/) ? 1 : 0

    # Column 6: Status of Assembly Gaps (Podarcis_muralis_PacBio)
    $6 = (tolower($6) ~ /^no/) ? 1 : 0

    # Column 7: Sig_Pvals_Count (wilcox.test)
    norm7 = tolower($7)
    gsub(/^[[:space:];"]+|[[:space:];"]+$/, "", norm7)   # trim spaces, quotes, semicolons
    $7 = (norm7 == "" || norm7 == "na" || norm7 == "n/a") ? 0 : (($7+0 > 0) ? 1 : 0)

    # Column 8: IG10_Pval
    norm8 = tolower($8)
    gsub(/^[[:space:];"]+|[[:space:];"]+$/, "", norm8)
    $8 = (norm8 == "" || norm8 == "na" || norm8 == "n/a") ? 0 : (($8+0 < 0.05) ? 1 : 0)

    # Column 9: MPLE_Pval
    norm9 = tolower($9)
    gsub(/^[[:space:];"]+|[[:space:];"]+$/, "", norm9)
    $9 = (norm9 == "" || norm9 == "na" || norm9 == "n/a") ? 0 : (($9+0 < 0.05) ? 1 : 0)

    # Column 10: Genome Blast Coverage
    $10 = ($10+0 < 75) ? 1 : 0

    # Column 11: GC-content (mean +/- SD) #(Salve et al., 2024)
    $11 = ($11+0 >= 35 && $11+0 <= 60) ? 1 : 0

    # Column 12: GC-Stretch (mean +/- SD)#(Janusova et al., 2023)
    $12 = ($12+0 < 4.5) ? 1 : 0

    # Column 13: Sequence identity with human ortholog#(Salve et al., 2024b)
    $13 = ($13+0 > 65) ? 1 : 0

    # Column 14: Paralogs status
    $14 = (tolower($14) ~ /^no/) ? 1 : 0

    # Column 15: Closest paralog (IQ-TREE) -> 1 if NA/empty, else 0
    norm15 = tolower($15)
    gsub(/^[[:space:];"]+|[[:space:];"]+$/, "", norm15)
    $15 = (norm15 == "" || norm15 == "na" || norm15 == "n/a") ? 1 : 0

    # Print modified row
    print
}
' "$input" > "$output"

echo "Binary conversion done. Output saved to $output"
