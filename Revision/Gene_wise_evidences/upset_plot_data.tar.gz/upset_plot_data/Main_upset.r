setwd("/home/sonal/Documents/upset_plot")
getwd()
# ---- 1. Load All Necessary Libraries ----

library(ggplot2)
library(patchwork)
library(dplyr)
library(tidyr)
library(ComplexUpset)
library(RColorBrewer)
library(vioplot)
library(png)
library(grid)
library(sm)


# ---- 2. The Custom Plotting Function ----
# (This function remains unchanged)
create_vioplot_panel <- function(df_list, value_cols, ylab_texts, hlines, ylims, gene_order,
                                 filename, trim = TRUE, wex = 0.4, xlim = NULL,
                                 show_names = TRUE, colMed = "black") {
  
  n_plots <- length(df_list)
  n_genes <- length(gene_order)
  palette <- colorRampPalette(RColorBrewer::brewer.pal(9, "Set1"))(n_genes)
  
  if (is.null(xlim)) {
    xlim <- c(0.5, n_genes + 0.5)
  }
  
  png(filename, width = 8000, height = n_plots * 470, res = 300)
  par(mfrow = c(n_plots, 1))
  
  for (j in 1:n_plots) {
    df <- df_list[[j]]
    value_col <- value_cols[j]
    df_filtered <- df %>%
      filter(Gene_name %in% gene_order) %>%
      mutate(Gene_name = factor(Gene_name, levels = gene_order))
    data_list <- split(df_filtered[[value_col]], df_filtered$Gene_name)
    
    is_last_plot <- (j == n_plots)
    par(mar = if(is_last_plot && show_names) c(5, 5, 1.5, 1) else c(1.5, 5, 1.5, 1))
    
    plot(1, type = "n", xlim = xlim, ylim = ylims[[j]], xlab = "", ylab = "", axes = FALSE)
    
    for (i in 1:n_genes) {
      current_data <- na.omit(data_list[[i]])
      if (length(current_data) < 2) next
      
      density_est <- sm::sm.density(current_data, display = "none", h = sm::h.select(current_data))
      base_coords <- density_est$eval.points
      height_coords <- density_est$estimate
      
      if (trim) {
        min_val <- min(current_data); max_val <- max(current_data)
        indices_to_keep <- which(base_coords >= min_val & base_coords <= max_val)
        base_coords <- base_coords[indices_to_keep]
        height_coords <- height_coords[indices_to_keep]
      }
      
      scaled_height <- height_coords / max(height_coords, na.rm = TRUE) * wex
      
      polygon(c(i - scaled_height, rev(i + scaled_height)),
              c(base_coords, rev(base_coords)),
              col = palette[i], border = "black")
      
      stats <- boxplot.stats(current_data)$stats
      segments(i, stats[1], i, stats[5], col = "black")
      rect(i - 0.1, stats[2], i + 0.1, stats[4], col = "black")
      points(i, stats[3], pch = 19, col = colMed, cex = 1.2)
      # Set y-positions relative to each plot's specific ylims.
      if (j == 1 | j == n_plots) {
        # For the TOP plot (j=1) and BOTTOM plot (j=n_plots): position near TOP
        y_pos_base <- ylims[[j]][2] * 0.95 
      } else {
        # For all MIDDLE plots: position near BOTTOM
        y_pos_base <- ylims[[j]][1] + (diff(ylims[[j]]) * 0.05)
      }
      
      # Calculate a small vertical offset (e.g., 5% of the y-axis range)
      vertical_offset <- diff(ylims[[j]]) * 0.09
      
      # Place the labels vertically (up and down)
      if (j == 1 | j == n_plots) {
        # TOP PLOT AND BOTTOM PLOT: Place median, then place n-count BELOW it.
        text(i, y_pos_base, labels = round(stats[3], 0), col = "red", cex = 0.6)
        text(i, y_pos_base - vertical_offset, labels = paste0("n=", length(current_data)), col = "blue", cex = 0.6)
      } else {
        # MIDDLE PLOTS: Place median, then place n-count ABOVE it.
        text(i, y_pos_base, labels = round(stats[3], 0), col = "red", cex = 0.6)
        text(i, y_pos_base + vertical_offset, labels = paste0("n=", length(current_data)), col = "blue", cex = 0.6)
      }
    }
    
    axis(2, las = 1)
    mtext(ylab_texts[j], side = 2, line = 3)
    if (!is.null(hlines[[j]])) abline(h = hlines[[j]], lty = 2, col = "red")
    box()
    
    if (is_last_plot) {
      if (show_names) {
        axis(1, at = 1:n_genes, labels = gene_order, las = 2, cex.axis = 0.8)
        mtext("Gene Name", side = 1, line = 4, cex = 1)
      } else {
        axis(1, at = 1:n_genes, labels = FALSE, tick = FALSE)
      }
    }
  }
  dev.off()
}


# ---- 3. Load Data ----
# Load main data for stacked bar plot and master palette
df_genes <- read.table("briefed_All_evidences_Upset_binary.tsv", sep = "\t", header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
colnames(df_genes) <- trimws(colnames(df_genes)); colnames(df_genes) <- gsub(" ", "_", colnames(df_genes))
df_genes$EvidenceScore <- rowSums(df_genes[, -1], na.rm = TRUE)
#View(df_genes)
gene_order <- df_genes %>% arrange(EvidenceScore) %>% pull(Gene)

# Load data for the two UpSet plots
df_segmental <- read.table("briefed_binary_segmental.tsv", sep = "\t", header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
df_rearrangement <- read.table("briefed_binary_Rearrangement.tsv", sep = "\t", header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)

# Load data for ALL FOUR violin plots
df1 <- read.table("Gene_species_Max_coverage.tsv", header = TRUE, sep = '\t') %>% na.omit()
df2 <- read.table("Identity_wrt_human.tsv", header = TRUE, sep = '\t') %>% na.omit()
df3 <- read.table("GC_content.tsv", header = TRUE, sep = '\t') %>% na.omit()
df4 <- read.table("GC_Stretch.tsv", header = TRUE, sep = '\t') %>% na.omit()

# ---- 4. Create Master Color Palette ----
# Create master palette from ALL evidence types in the main dataset
all_evidence_types <- colnames(df_genes)[!colnames(df_genes) %in% c("Gene", "EvidenceScore")]
evidence_palette_full <- colorRampPalette(RColorBrewer::brewer.pal(9, "Set1"), space = "Lab")(length(all_evidence_types))
names(evidence_palette_full) <- all_evidence_types

# ---- 5. Create UpSet Plots ----

# Function to create UpSet plot using master palette
create_upset_plot <- function(df, title, master_palette) {
  # Clean column names
  colnames(df) <- trimws(colnames(df))
  colnames(df) <- gsub(" ", "_", colnames(df))
  
  # Convert to binary
  df[,-1] <- lapply(df[,-1], function(x) as.integer(x > 0))
  
  # Add EvidenceScore from main data
  df <- df %>%
    left_join(df_genes %>% select(Gene, EvidenceScore), by = "Gene")
  
  min_score <- min(df$EvidenceScore, na.rm = TRUE)
  
  # Font size settings
  base_font_size <- 1.1
  size_increase_per_point <- 0.15
  
  df <- df %>%
    mutate(
      FontSize = base_font_size + (EvidenceScore - min_score) * size_increase_per_point
    )
  
  # Get evidence types for THIS specific plot
  evidence_types <- colnames(df)[!colnames(df) %in% c("Gene", "EvidenceScore", "FontSize")]
  
  # Use the provided master palette, subsetting for only the evidence types in this plot
  plot_palette <- master_palette[evidence_types]
  
  # Create queries using the subsetted master palette
  evidence_queries <- lapply(evidence_types, function(evidence_type) {
    upset_query(
      set = evidence_type,
      fill = plot_palette[evidence_type],
      color = plot_palette[evidence_type],
      only_components = c("intersections_matrix")
    )
  })
  
  # Create UpSet plot
  upset_plot <- ComplexUpset::upset(
    df,
    intersect = evidence_types,
    name = 'Evidence',
    height_ratio = 0.75,
    sort_sets = FALSE,
    base_annotations = list(
      'Intersection size' = (
        intersection_size(
          text = list(size = 3, col= "black")
        )
        + geom_text(
          mapping = aes(
            label = Gene,
            size = FontSize
          ),
          color = "white",
          fontface = "bold.italic",
          position = position_stack(vjust = 0.5),
          angle = 90
        )
        + scale_size_identity(guide = "none")
        + theme(
          axis.title.y = element_text(size=9, vjust =-56),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
      )
    ),
    queries = evidence_queries,
    min_size = 1,
    n_intersections = 50
  ) +
    theme(
      text = element_text(size=8),
      axis.text.y = element_text(size=7, colour="black"),
      axis.title.x = element_text(size=9, vjust =2),
      plot.title = element_text(size=10, hjust = 0.5, vjust = 40),
      panel.spacing.y = unit(0.05, "cm"),
      plot.margin = margin(2,2,-14,2)
    ) & theme(
      plot.margin = margin(2,-2,-14,-2) # optional tighter margins
    )
  
  return(upset_plot)
}

# Create both UpSet plots USING THE MASTER PALETTE
upset_segmental <- create_upset_plot(df_segmental, "Segmental Deletion based on Synteny \n     (n = 36)", evidence_palette_full)
upset_rearrangement <- create_upset_plot(df_rearrangement, "Chromosomal Rearrangement \n       (n = 17)", evidence_palette_full)

# ---- 6. Create Stacked Bar Plot ----
df_long <- df_genes %>% select(-EvidenceScore) %>%
  pivot_longer(cols = -Gene, names_to = "EvidenceType", values_to = "HasEvidence") %>%
  filter(HasEvidence > 0)
df_long$Gene <- factor(df_long$Gene, levels = gene_order)

stacked_score_plot <- ggplot(df_long, aes(x = Gene, fill = EvidenceType)) +
  geom_bar(position = "stack", width = 0.8) + 
  scale_fill_manual(values = evidence_palette_full) +  # Use master palette
  theme_minimal(base_size = 10) +
  labs(x = NULL, y = "Evidence Score", fill = "Evidence Type") +
  theme(
    axis.text.x = element_text(angle=90, hjust=1, size=8, colour="black", face = "italic"),
    axis.ticks.x = element_blank(),
    panel.grid.major.x = element_blank(), 
    panel.grid.minor = element_blank(),
    legend.position = "none"
  )

# ---- 7. Create Violin Plots ----
create_vioplot_panel(
  df_list = list(df1, df2, df3, df4),
  value_cols = c("Max_cov", "Seq.Identity", "GC_content", "GC_Stretch"),
  ylab_texts = c("Max. Coverage", "Seq. Identity (%)", "GC-content (%)", "GC-Stretch (%)"),
  hlines = list(75, 65, 55, 4.5),
  ylims = list(c(-5, 105), c(-5, 105), c(20, 90), c(2.6, 7)),
  gene_order = gene_order,
  filename = "vioplot_panel_4plots.png",
  wex = 0.32,
  xlim = c(2.16, 51.5),
  show_names = FALSE,
  colMed = "white"
)

# Read the saved image back into R
vioplot_grob <- rasterGrob(readPNG("vioplot_panel_4plots.png"),
                           width = unit(1, "npc"),
                           interpolate=TRUE)

# ---- 8. Assemble and Save Final Figure ----
# Combine stacked bar plot and violin plots
aligned_gene_plot <- stacked_score_plot / vioplot_grob +
  plot_layout(heights = c(1.5, 4))

# Combine all plots in landscape layout (removed tag_levels)
final_figure <- wrap_plots(
  upset_segmental, 
  upset_rearrangement, 
  aligned_gene_plot,
  design = "
  AB
  CC
  ",
  widths = c(1.5, 1),  # upset_segmental:2, upset_rearrangement:1
  heights = c(1, 2)   # UpSet row:1, gene plot row:2
)

final_figure

ggsave("Main_upset.png", plot = final_figure,
       width = 16, height = 9, units = "in", dpi = 300, bg = "white")

# ---- 9. Create Legend ----
legend_df <- data.frame(
  EvidenceType_f = factor(names(evidence_palette_full), levels = all_evidence_types)
)

legend_plot <- ggplot(legend_df, aes(x = 1, y = EvidenceType_f, fill = EvidenceType_f)) +
  geom_tile() +
  scale_fill_manual(
    values = evidence_palette_full,
    name = "Evidence Type",
    breaks = all_evidence_types
  ) +
  theme_void() + 
  theme(
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 10),
    legend.key.size = unit(0.6, "cm")
  )

ggsave(
  filename = "Main_upset_legend.png",
  plot = legend_plot,
  width = 4.2,
  height = 6,
  units = "in",
  dpi = 300,
  bg = "transparent"
)