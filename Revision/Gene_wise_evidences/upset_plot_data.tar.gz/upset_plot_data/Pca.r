# --- 1. SETUP: Load Libraries and Set Directory ---

# Install packages if you haven't already
# install.packages(c("dplyr", "ggplot2", "ggrepel"))

library(dplyr)
library(ggplot2)
library(ggrepel)

# !!! IMPORTANT: Change this path to your folder !!!
setwd("/home/sonal/Documents/upset_plot")

df <- read.table("briefed_All_evidences_Upset_binary.tsv",
                 sep = "\t",
                 header = TRUE,
                 stringsAsFactors = FALSE,
                 check.names = FALSE)


# --- 2. Prepare the Data ---

# Set the 'Gene' column as row names for labeling
rownames(df) <- df$Gene

# Remove the non-numeric 'Gene' column for PCA analysis
df_pca_ready <- df %>% select(-Gene)

# (Optional but good practice) Remove zero-variance columns
is_zero_variance <- apply(df_pca_ready, 2, var) == 0
if(any(is_zero_variance)) {
  cat("Removing columns with zero variance:", names(df_pca_ready)[is_zero_variance], "\n")
  df_pca_ready <- df_pca_ready[, !is_zero_variance]
}


# --- 3. Perform Principal Component Analysis ---
pca_result <- prcomp(df_pca_ready, scale. = TRUE)

# Extract scores (for genes)
pca_scores <- as.data.frame(pca_result$x)
pca_scores$Gene <- rownames(pca_scores) # Add gene names back for plotting

# Extract loadings (for evidence types)
pca_loadings <- as.data.frame(pca_result$rotation)
pca_loadings$EvidenceType <- rownames(pca_loadings)

# Get percentage of variance explained for axis labels
variance_explained <- summary(pca_result)$importance[2, 1:2] * 100


# --- 4. CREATE THE PCA BI-PLOT WITH ADJUSTED FONT SIZES AND TRANSPARENT BACKGROUND ---

# This version plots ALL gene names and reduces the font size for clarity.
pca_plot_small_fonts <- ggplot() +
  # Arrows for evidence types (prominent red)
  geom_segment(data = pca_loadings, aes(x = 0, y = 0, xend = PC1 * 5, yend = PC2 * 5),
               arrow = arrow(length = unit(0.25, "cm")), color = "darkred", size = 0.8) +

  # Labels for evidence types (font size reduced)
  geom_text_repel(data = pca_loadings, aes(x = PC1 * 5.5, y = PC2 * 5.5, label = EvidenceType),
                  size = 3, color = "darkred", fontface = "bold", max.overlaps = 20) + # MODIFIED: size = 3

  # Points for genes (lighter blue, slightly transparent)
  geom_point(data = pca_scores, aes(x = PC1, y = PC2), color = "steelblue", alpha = 0.6, size = 2.5) +

  # Labels for ALL genes (font size reduced)
  geom_text_repel(data = pca_scores, aes(x = PC1, y = PC2, label = Gene),
                  size = 2, color = "black", max.overlaps = 20) + # MODIFIED: data = pca_scores, size = 2

  # Title and axis labels
  labs(
    x = sprintf("PC1 (%.1f%% Variance)", variance_explained[1]),
    y = sprintf("PC2 (%.1f%% Variance)", variance_explained[2])
  ) +
  # Clean theme, no grid lines
  theme_minimal(base_size = 14) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.line = element_line(color = "black"),
    panel.border = element_blank(),
    plot.background = element_rect(fill = "white", colour = NA), # ADDED: Transparent background
    panel.background = element_rect(fill = "white", colour = NA)  # ADDED: Transparent panel background
  ) +
  # Add subtle origin lines
  geom_hline(yintercept = 0, linetype = "dotted", color = "black") +
  geom_vline(xintercept = 0, linetype = "dotted", color = "black")

# Print and save the updated plot with transparent background
print(pca_plot_small_fonts)
ggsave("PCA_Biplot_SmallLabels.png",
       plot = pca_plot_small_fonts,
       width = 12,
       height = 10,
       dpi = 300,
       bg = "transparent") # KEY CHANGE: bg = "transparent"

cat("\nPCA biplot with smaller font sizes and transparent background saved as 'PCA_Biplot_SmallLabels_Transparent.png'\n")
