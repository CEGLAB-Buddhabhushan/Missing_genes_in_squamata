#!/bin/bash
# Usage: ./binary_convert.sh input.tsv output.tsv
# Converts your table into binary format (0/1) according to rules.

input="$1"
output="$2"

awk -F'\t' -v OFS='\t' '
NR==1 {               # First row (header) → print as is
    print; next
}
{
    # Column 1: Gene name → keep unchanged
    # $1 = $1   (no modification needed)

    # -----------------------------
    # Column 2: Synteny Proof (Segmental deletion)
    $2 = (tolower($2) ~ /^yes/) ? 1 : 0

    # Column 3: Synteny Proof (Intrachromosomal Rearrangement)
    $3 = (tolower($3) ~ /^yes/) ? 1 : 0

    # Column 4: Synteny Proof (Interchromosomal Rearrangement)
    $4 = (tolower($4) ~ /^yes/) ? 1 : 0

    # Column 5: Status of Assembly Gaps (Crotalus_tigris PacBio)
    $5 = (tolower($5) ~ /^no/) ? 1 : 0

    # Column 6: Status of Assembly Gaps (Pogona_vitticeps_Nanopore)
    $6 = (tolower($6) ~ /^no/) ? 1 : 0

    # Column 7: Status of Assembly Gaps (Podarcis_muralis_PacBio)
    $7 = (tolower($7) ~ /^no/) ? 1 : 0

    # Column 8: Sig_Pvals_Count (wilcox.test)
    norm8 = tolower($8)
    gsub(/^[[:space:];"]+|[[:space:];"]+$/, "", norm8)   # trim spaces, quotes, semicolons
    $8 = (norm8 == "" || norm8 == "na" || norm8 == "n/a") ? 0 : (($8+0 > 0) ? 1 : 0)

    # Column 9: IG10_Pval
    norm9 = tolower($9)
    gsub(/^[[:space:];"]+|[[:space:];"]+$/, "", norm9)   # trim spaces, quotes, semicolons
    $9 = (norm9 == "" || norm9 == "na" || norm9 == "n/a") ? 0 : (($9+0 < 0.05) ? 1 : 0)

# Column 10: MPLE_Pval
    norm10 = tolower($10)
    gsub(/^[[:space:];"]+|[[:space:];"]+$/, "", norm10)
    $10 = (norm10 == "" || norm10 == "na" || norm10 == "n/a") ? 0 : (($10+0 < 0.05) ? 1 : 0)
# Column 11: Genome Blast Coverage
    $11 = ($11+0 < 75) ? 1 : 0

    # Column 12: GC-content (mean +/- SD) #(Salve et al., 2024)
    $12 = ($12+0 >= 35 && $12+0 <= 60) ? 1 : 0

    # Column 13: GC-Stretch (mean +/- SD)#(Janusova et al., 2023)
    $13 = ($13+0 < 4.5) ? 1 : 0

    # Column 14: Sequence identity with human ortholog#(Salve et al., 2024b)
    $14 = ($14+0 > 65) ? 1 : 0

    # Column 15: Paralogs status
    $15 = (tolower($15) ~ /^no/) ? 1 : 0

    # Column 16: Closest paralog (IQ-TREE) -> 1 if NA/empty, else 0
    norm16 = tolower($16)
    gsub(/^[[:space:];"]+|[[:space:];"]+$/, "", norm16)  # trim spaces, ;, "
    $16 = (norm16 == "" || norm16 == "na" || norm16 == "n/a") ? 1 : 0


    # Print modified row
    print
}
' "$input" > "$output"

echo "✅ Binary conversion done. Output saved to $output"

