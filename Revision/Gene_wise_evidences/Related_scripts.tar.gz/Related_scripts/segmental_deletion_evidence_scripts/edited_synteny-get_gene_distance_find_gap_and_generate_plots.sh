#!/bin/bash

#conda activate ncbi_datasets
TARGET_GENE=$1

#cut -f1,5,7-9,15-16 GCF_000001405.40_GRCh38.p14_feature_table.txt|awk '$1=="gene"'|grep -A20 -B20 "$TARGET_GENE"|cut -f6 > #"$TARGET_GENE"_human.lst
#for i in `cat "$TARGET_GENE"_human.lst`
#do
#grep -w "$i" All_gene.Outgroup_acc.tsv
#done | cut -f1 |grep -A2 -B2 -w "$TARGET_GENE"|grep -v "$TARGET_GENE" > "$TARGET_GENE"_human_sorted.lst
# === Check if exactly 4 rows present ===
#lines=$(wc -l < "${TARGET_GENE}_human_sorted.lst")

#if [ "$lines" -ne 4 ]; then
  #echo "Problem in synteny for $TARGET_GENE — expected 4 genes, found $lines."
  #exit 1
#else
  #echo "Synteny check passed — 4 genes found for $TARGET_GENE."
#fi

#for i in `cat "$TARGET_GENE"_human_sorted.lst`
#do
#awk -F'\t' -v var="$i" '$1=="gene" && $15==var {print $15"-"$16}' GCF_000001405.40_GRCh38.p14_feature_table.txt >> #"$TARGET_GENE"_syntenic_genes.lst
#done 

while read gene; do
    awk -F'\t' -v g="$gene" '$1=="gene" && $15==g {print $15"-"$16}' GCF_000001405.40_GRCh38.p14_feature_table.txt
done < "$TARGET_GENE"_syntenic_genes.lst > "$TARGET_GENE"_syntenic_genes_with_ids.lst

rm -r "$TARGET_GENE"_deletion
mkdir  "$TARGET_GENE"_deletion
cd "$TARGET_GENE"_deletion
mkdir CDS_filtered
for i in `cat ../"$TARGET_GENE"_syntenic_genes_with_ids.lst`
do
gene=`echo $i | cut -f1 -d'-'`
gene_id=`echo $i | cut -f2 -d'-'`

datasets download gene gene-id $gene_id --include product-report --ortholog all --no-progressbar --api-key c181c44f2dca87803a9c0f9a24a32f67a608 --filename "$gene".zip
rm -rf "$gene"
unzip -q -o "$gene".zip -d "$gene"
rm "$gene".zip
cd "$gene/ncbi_dataset/data"
dataformat tsv gene-product --inputfile product_report.jsonl  > gene_product.tsv
dataformat tsv gene-product --inputfile product_report.jsonl --fields gene-id,tax-name,symbol,transcript-accession,transcript-length,transcript-protein-accession,transcript-protein-length > transcript_protein.tsv

mkdir -p CDS_sorted

for species_name in `cut -f2 -d'-' /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/Vertebrate-RefSeqAnno.444.lst|sort -u`
    do
        j=`echo $species_name | sed 's/_/ /g'`
        LONGEST=`grep "$j" transcript_protein.tsv | sort -t$'\t' -nr -k7 | head -n1 | cut -f4`

        # Proceed only if LONGEST is found (not empty)
        if [ -n "$LONGEST" ]; then
            accession=`grep "$species_name" /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/Vertebrate-RefSeqAnno.444.lst | cut -f1 -d'-'`
            datasets download genome accession $accession --include gff3 --no-progressbar --api-key c181c44f2dca87803a9c0f9a24a32f67a608 --filename "$species_name".zip
            rm -rf $species_name
            unzip -q -o "$species_name".zip -d $species_name
            rm "$species_name".zip

            gff2bed < $species_name/ncbi_dataset/data/$accession/genomic.gff  > $species_name/ncbi_dataset/data/$accession/genomic.gff.bed
            grep -w "$LONGEST" $species_name/ncbi_dataset/data/$accession/genomic.gff.bed | grep -P "\tCDS\t" | cut -f1-6 | sort -k1,1 -k2,2n | bedtools merge -i stdin -d 7500000 -s > CDS_sorted/"$species_name"."$gene".bed
            
            [ -s CDS_sorted/"$species_name"."$gene".bed ] || rm -f CDS_sorted/"$species_name"."$gene".bed
            rm -r $species_name
            echo $species_name
        else
            echo "Skipping $species_name for $gene (No longest transcript found)"
        fi
done

cd CDS_sorted
ls -1 *.bed|cut -f1 -d'.'|sort -u > /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_deletion/CDS_filtered/"$gene".species.lst
cd /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_deletion
done

# get common species which have annoated in all genes

cd CDS_filtered
gene1=`cat /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_syntenic_genes_with_ids.lst|cut -f1 -d'-'|tr '\n' '\t' |awk '{print $1}'`
gene2=`cat /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_syntenic_genes_with_ids.lst|cut -f1 -d'-'|tr '\n' '\t' |awk '{print $2}'`
gene3=`cat /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_syntenic_genes_with_ids.lst|cut -f1 -d'-'|tr '\n' '\t' |awk '{print $3}'`
gene4=`cat /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_syntenic_genes_with_ids.lst|cut -f1 -d'-'|tr '\n' '\t' |awk '{print $4}'`
echo $gene1  $gene2  $gene3  $gene4
comm -12 <(sort -u "$gene1".species.lst) <(sort -u "$gene2".species.lst) | comm -12 - <(sort -u "$gene3".species.lst) | comm -12 - <(sort -u "$gene4".species.lst) > common.species.lst 
for gene in `cat ../../"$TARGET_GENE"_syntenic_genes_with_ids.lst|cut -f1 -d'-'|tr '\n' ' '`
do
mkdir $gene
for species_name in `cat common.species.lst`
do
cp /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_deletion/$gene/ncbi_dataset/data/CDS_sorted/"$species_name"."$gene".bed $gene
done
done

##### Get gene distance table
genes=($(cat ../../"$TARGET_GENE"_syntenic_genes_with_ids.lst|cut -f1 -d'-'|tr '\n' ' '))

# Create an output file
output_file="gene_distances.tsv"

# Print header with all gene pair combinations
echo -ne "Species\t" > $output_file
for ((i=0; i<${#genes[@]}; i++)); do
    for ((j=i+1; j<${#genes[@]}; j++)); do
        echo -ne "${genes[i]}-${genes[j]}\t" >> $output_file
    done
done
echo "" >> $output_file

# Read species list from common.species.lst
species_list=($(cat common.species.lst))

# Process each species
for species in "${species_list[@]}"; do
    echo -ne "$species\t" >> $output_file  # Start a new row with species name
    
    for ((i=0; i<${#genes[@]}; i++)); do
        for ((j=i+1; j<${#genes[@]}; j++)); do
            gene1=${genes[i]}
            gene2=${genes[j]}
            
            file1="$gene1/$species.$gene1.bed"
            file2="$gene2/$species.$gene2.bed"
            
            if [[ -f "$file1" && -f "$file2" ]]; then
                # Run bedtools closest
                result=$(bedtools closest -a "$file1" -b "$file2" -d | awk 'NR==1 {print $1, $NF}')  # Get chromosome and distance
                
                chr1=$(echo "$result" | awk '{print $1}')  # Chromosome of gene1
                distance=$(echo "$result" | awk '{print $2}')  # Distance
                
                # Check if chromosomes are different (EBR case)
                if [[ "$chr1" != "$(awk 'NR==1 {print $1}' $file2)" ]]; then
                    distance="EBR"
                fi
            else
                distance="NA"  # If one gene is missing
            fi
            
            echo -ne "$distance\t" >> $output_file
        done
    done
    echo "" >> $output_file  # New row for the next species
done

echo "Pairwise gene distances saved in $output_file."
grep -v "EBR" gene_distances.tsv > gene_distances.sorted.tsv
cut -f1 gene_distances.sorted.tsv | tail -n +2 > species_list.txt
for i in `cat species_list.txt`
do
species=`echo $i |sed 's/_/ /g'`
order=`esearch -db taxonomy -query "$species" | efetch -format xml | xmllint --xpath "//LineageEx/Taxon[Rank='order']/ScientificName/text()" -`
class=`esearch -db taxonomy -query "$species" | efetch -format xml | xmllint --xpath "//LineageEx/Taxon[Rank='class']/ScientificName/text()" -`
echo -e "$class\t$order\t$i" >> taxonomy_info.tsv
done




### find gaps
echo -e "Species\tNum_Gaps" > gap_summary.tsv  # Header for TSV file

for i in $(cat species_list.txt); do
    # Merge BED regions
    merged_region=$(cat $gene1/"$i"."$gene1".bed $gene4/"$i"."$gene4".bed | \
                    sort -k1,1 -k2,2n | \
                    bedtools merge -i - -d 100000000)

    # Extract chromosome ID, start, and stop positions
    id=$(echo "$merged_region" | cut -f1)
    chr_start=$(echo "$merged_region" | cut -f2)
    chr_stop=$(echo "$merged_region" | cut -f3)

    # Fetch FASTA and find gaps
    efetch -db nuccore -id $id -format fasta -chr_start $chr_start -chr_stop $chr_stop | \
        gzip > "$i"."$gene1"_"$gene4".fasta.gz

    klumpy find_gaps --fasta "$i"."$gene1"_"$gene4".fasta.gz 

    # Check if the gaps file exists, else set num_gaps = 0
    if [[ -f "$i"."$gene1"_"$gene4"_gaps.tsv ]]; then
        num_gaps=$(tail -n +2 "$i"."$gene1"_"$gene4"_gaps.tsv | wc -l)
    else
        num_gaps=0
    fi

    echo -e "$i\t$num_gaps" >> gap_summary.tsv
    rm "$i"."$gene1"_"$gene4".fasta.gz  "$i"."$gene1"_"$gene4"_gaps.tsv
done


head -n 1 gene_distances.sorted.tsv | awk '{print "Group\tOrder\tSpecies\tSpecies\tNum_Gaps\t"$0}'| awk 'BEGIN{OFS="\t"} $3==$4 && $4==$6 {print $2, $3, $5, $7, $8, $9, $10, $11, $12}' |sed 's/Species/Species_name/g;s/-/_/g' > final_output.tsv
paste taxonomy_info.tsv <(tail -n +2 gap_summary.tsv) <(tail -n +2 gene_distances.sorted.tsv) | awk 'BEGIN{OFS="\t"} $3==$4 && $4==$6 {print $2, $3, $5, $7, $8, $9, $10, $11, $12}' >> final_output.tsv
awk 'BEGIN{OFS="\t"} NR==1 {print $0, "Gene_status"; next} $1=="Squamata" {print $0, "Loss"; next} {print $0, "Intact"}' final_output.tsv > final_output_with_status.tsv
awk 'BEGIN{OFS="\t"} $1 != ""' final_output_with_status.tsv > final_output_with_status.filtered.tsv

cut -f2 final_output_with_status.filtered.tsv|tail -n+2> species_tree.lst
Rscript /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/heatmap_and_phylogenetic_regression_analyses.R 
cp Heatmap_of_deletion_plot.png /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_deletion/
cp Phylogenetic_signal_of_deletion_plot.png /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_deletion/
cp "$TARGET_GENE"_pvals_summary.tsv /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_deletion/
cd /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/"$TARGET_GENE"_deletion/
mv ../"$TARGET_GENE"_human.lst ../"$TARGET_GENE"_human_sorted.lst ../"$TARGET_GENE"_syntenic_genes_with_ids.lst .
cd /media/lokdeep/sdf/BUDDHA/BMCBIO/segmental_deletion/
