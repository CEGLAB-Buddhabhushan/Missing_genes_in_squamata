#!/usr/bin/env bash
# mapping script 

Base_dir="$(pwd)"
Threads=30

# Enable nullglob so globs that match nothing expand to nothing
shopt -s nullglob

SRA_data_type="Nanopore_subsetted"

for species in $(cat species_lst); do
  species="$species"

  cd "$species" || { echo "Cannot enter $species"; }

  for data_dir in $SRA_data_type; do
    cd "$data_dir" || { echo "Cannot enter $data_dir"; }
    echo "mapping $data_dir for $species"

    if [ "$data_dir" = "PacBio" ]; then
      ax_parameter="map-pb"
    else
      ax_parameter="map-ont"
    fi
    echo "will be using $ax_parameter"

    for fastq in *.fastq.gz; do
      minimap2 -ax "$ax_parameter" -t "$Threads" "$Base_dir/$species/genome"/*.fna "$fastq" \
        | samtools sort -@"$Threads" -O BAM -o "${fastq%.fastq.gz}.bam"
      samtools index "${fastq%.fastq.gz}.bam"
    done

    data_dir_merged="${data_dir}_merged.bam"
    samtools merge -@"$Threads" "$data_dir_merged" *.bam
    samtools sort -@"$Threads" "$data_dir_merged" -o "${data_dir}_merged.sorted.bam"
    samtools index -@"$Threads" "${data_dir}_merged.sorted.bam"

    cd ..
  done

  cd ..
done
