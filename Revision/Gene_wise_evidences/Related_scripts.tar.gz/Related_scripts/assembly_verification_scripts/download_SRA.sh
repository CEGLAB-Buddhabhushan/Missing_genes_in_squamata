#!/usr/bin/env bash
# Reads species from species_lst, enters each species directory,
# processes each subdirectory (e.g., PacBio, Nanopore),
# downloads SRA data via parallel-fastq-dump, and returns.
# To run in background with logging:
#   nohup bash simple_fastq_download.sh > download.log 2>&1 &
# Check progress with:
#   tail -f download.log

Threads=30

# Check for species list
if [[ ! -f species_lst ]]; then
  echo "Error: species_lst not found in $(pwd)"
  exit 1
fi

# Loop through each species
done_flag=false
while read -r species; do
  # Skip empty or commented lines
  [[ -z "$species" || "$species" == \#* ]] && continue

  echo "Processing species: $species"
  if [[ ! -d "$species" ]]; then
    echo "  Warning: Directory '$species' does not exist, skipping."
    continue
  fi

  cd "$species"

  # Loop through each subdirectory
  for sub in */; do
    sub=${sub%/}
    echo "  In subdirectory: $sub"
    if [[ ! -d "$sub" ]]; then
      echo "    Warning: '$sub' is not a directory, skipping."
      continue
    fi

    cd "$sub"
    if [[ ! -f SRA.lst ]]; then
      echo "    Warning: SRA.lst not found in $sub, skipping."
      cd ..
      continue
    fi

    # Download each SRA ID
    while read -r id; do
      [[ -z "$id" ]] && continue
      echo "    Downloading $id"
      parallel-fastq-dump --sra-id "$id" --threads $Threads --outdir . --gzip
    done < SRA.lst

    cd ..
  done

  cd ..
done < species_lst

echo "All downloads completed."
