#!/usr/bin/env bash
# pipeline: klumpy analysis on merged BAMs for PacBio and Nanopore

Threads=30
Base_dir="$(pwd)"
SRA_data_type="Nanopore_subsetted"

for species in $(cat species_lst); do
  species="$species"
  cd "$species" || { echo "Cannot enter $species"; continue; }

  for data_dir in $SRA_data_type; do
    cd "$data_dir" || { echo "Cannot enter $data_dir"; continue; }

    # Define merged sorted BAM filename
    sorted_bam="${data_dir}_merged.sorted.bam"

    # Run klumpy if sorted BAM exists
    if [[ -f "$sorted_bam" ]]; then
      klumpy scan_alignments --alignment_map "$sorted_bam" \
        --threads "$Threads" \
        --annotation "$Base_dir/$species/genome"/*.gtf

      klumpy find_gaps --fasta "$Base_dir/$species/genome"/*.fna
    else
      echo "Warning: $sorted_bam not found, skipping klumpy steps."
    fi

    cd ..
  done

  cd ..
done
